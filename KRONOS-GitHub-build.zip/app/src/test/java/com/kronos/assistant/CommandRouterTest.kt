package com.kronos.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class CommandRouterTest {
    @Test fun timeEnglish() = assertEquals(Command.Time, CommandRouter.parse("What time is it?"))
    @Test fun timeHinglish() = assertEquals(Command.Time, CommandRouter.parse("kitne baje hain"))
    @Test fun dateHindi() = assertEquals(Command.Date, CommandRouter.parse("आज की तारीख क्या है"))
    @Test fun dateEnglish() = assertEquals(Command.Date, CommandRouter.parse("what's the date"))
    @Test fun notifications() = assertEquals(Command.Notifications, CommandRouter.parse("read my notifications"))
    @Test fun openEnglish() = assertEquals(Command.OpenApp("whatsapp"), CommandRouter.parse("Open WhatsApp"))
    @Test fun openHindiSuffix() = assertEquals(Command.OpenApp("व्हाट्सएप"), CommandRouter.parse("व्हाट्सएप खोलो"))
    @Test fun openHinglishSuffix() = assertEquals(Command.OpenApp("camera"), CommandRouter.parse("camera kholo"))
    @Test fun scanDownloads() = assertEquals(Command.ScanDownloads, CommandRouter.parse("scan my downloads"))
    @Test fun showDownloads() = assertEquals(Command.Downloads, CommandRouter.parse("show my downloads"))
    @Test fun deleteKeepsFilename() = assertEquals(Command.Delete("setup.apk"), CommandRouter.parse("delete setup.apk"))
    @Test fun yesEnglish() = assertEquals(Command.Yes, CommandRouter.parse("Yes"))
    @Test fun yesHinglish() = assertEquals(Command.Yes, CommandRouter.parse("haan"))
    @Test fun noHindi() = assertEquals(Command.No, CommandRouter.parse("नहीं"))
    @Test fun stopListening() = assertEquals(Command.Stop, CommandRouter.parse("stop listening"))
    @Test fun jokeGoesToAi() = assertEquals(Command.Ask("tell me a joke"), CommandRouter.parse("tell me a joke"))
    @Test fun howToDownloadGoesToAi() {
        assertEquals(Command.Ask("how do I download an app"), CommandRouter.parse("how do I download an app"))
    }
}
