package com.kronos.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class SafetyAndSpeechTest {
    @Test fun doubleExtensionIsHigh() =
        assertEquals(RiskLevel.HIGH, DownloadSafety.assess("invoice.pdf.exe").level)

    @Test fun windowsProgramIsHigh() =
        assertEquals(RiskLevel.HIGH, DownloadSafety.assess("setup.exe").level)

    @Test fun apkIsCaution() =
        assertEquals(RiskLevel.CAUTION, DownloadSafety.assess("game.apk").level)

    @Test fun piratedNameIsCaution() =
        assertEquals(RiskLevel.CAUTION, DownloadSafety.assess("photoshop crack.zip").level)

    @Test fun rtlTrickIsHigh() =
        assertEquals(RiskLevel.HIGH, DownloadSafety.assess("photo‮gpj.exe").level)

    @Test fun normalPdfIsSafe() = assertEquals(RiskLevel.SAFE, DownloadSafety.assess("notes.pdf").level)

    @Test fun partialDownloadDetected() {
        assertTrue(DownloadSafety.isInProgress("movie.mp4.crdownload"))
        assertFalse(DownloadSafety.isInProgress("movie.mp4"))
    }

    @Test fun timeEnglish() = assertEquals("It's 2:10 PM.", Speakables.timeText(LocalTime.of(14, 10), false))

    @Test fun timeMidnight() = assertEquals("It's 12:05 AM.", Speakables.timeText(LocalTime.of(0, 5), false))

    @Test fun timeHindi() =
        assertEquals("अभी दोपहर के 2 बजकर 10 मिनट हुए हैं।", Speakables.timeText(LocalTime.of(14, 10), true))

    @Test fun dateEnglish() =
        assertEquals("Today is Saturday, 14 November 2026.", Speakables.dateText(LocalDate.of(2026, 11, 14), false))

    @Test fun dateHindi() =
        assertEquals("आज 14 नवंबर 2026, शनिवार है।", Speakables.dateText(LocalDate.of(2026, 11, 14), true))

    @Test fun otpNotificationIsNeverReadAloud() {
        val items = listOf(NotifItem("Bank", "Your OTP", "OTP is 482913", 1L))
        val spoken = Speakables.notificationsText(items, false)
        assertFalse(spoken.contains("482913"))
        assertTrue(spoken.contains("hidden"))
    }

    @Test fun emptyNotifications() =
        assertEquals("I don't see any recent notifications.", Speakables.notificationsText(emptyList(), false))

    @Test fun appMatching() {
        val labels = listOf("Camera", "Chrome", "WhatsApp", "Settings")
        assertEquals(2, AppMatch.bestMatch("whatsapp", labels))
        assertEquals(2, AppMatch.bestMatch("व्हाट्सएप", labels))
        assertEquals(1, AppMatch.bestMatch("the Chrome app", labels))
        assertEquals(0, AppMatch.bestMatch("cam", labels))
        assertNull(AppMatch.bestMatch("zzzz", labels))
    }
}
