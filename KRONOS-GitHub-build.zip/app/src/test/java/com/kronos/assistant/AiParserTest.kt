package com.kronos.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AiParserTest {
    @Test fun aiRequestAndReplyParsing() {
        val req = AiParser.buildRequest("m", "sys", listOf(ChatMsg("user", "hi")))
        assertTrue(req.contains("\"model\":\"m\""))
        val ok = """{"choices":[{"message":{"role":"assistant","content":" Hello there "}}]}"""
        assertEquals("Hello there", AiParser.parseReply(ok))
        assertNull(AiParser.parseReply("not json"))
        assertNull(AiParser.parseReply("""{"choices":[]}"""))
        assertNotNull(AiParser.SYSTEM_PROMPT)
    }

    @Test fun httpErrorsAreClassified() {
        assertEquals(ErrKind.AUTH, AiParser.classify(401))
        assertEquals(ErrKind.RATE_LIMIT, AiParser.classify(429))
        assertEquals(ErrKind.SERVER, AiParser.classify(500))
    }
}
