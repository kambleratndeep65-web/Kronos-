package com.kronos.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeAndLangTest {
    @Test fun wakePhraseAlone() {
        val r = WakeMatcher.match("Hello KRONOS")
        assertTrue(r.matched)
        assertEquals("", r.remainder)
    }

    @Test fun wakePhraseWithCommand() {
        val r = WakeMatcher.match("hello kronos what time is it")
        assertTrue(r.matched)
        assertEquals("what time is it", r.remainder)
    }

    @Test fun wakePhraseMisspelledByRecognizer() = assertTrue(WakeMatcher.match("hello chronos").matched)

    @Test fun wakePhraseDevanagari() = assertTrue(WakeMatcher.match("हेलो क्रोनोस").matched)

    @Test fun noWakePhrase() = assertFalse(WakeMatcher.match("hello world").matched)

    @Test fun insideAnotherWordDoesNotWake() = assertFalse(WakeMatcher.match("this kronos").matched)

    @Test fun devanagariIsHindi() = assertTrue(LangDetect.isHindi("आज मौसम कैसा है"))

    @Test fun hinglishIsHindi() = assertTrue(LangDetect.isHindi("mujhe time batao"))

    @Test fun plainEnglishIsNotHindi() = assertFalse(LangDetect.isHindi("what is the weather"))

    @Test fun devanagariReplyUsesHindiVoice() = assertTrue(LangDetect.replyIsHindi("आज शनिवार है"))

    @Test fun englishReplyUsesEnglishVoice() = assertFalse(LangDetect.replyIsHindi("Today is Saturday"))
}
