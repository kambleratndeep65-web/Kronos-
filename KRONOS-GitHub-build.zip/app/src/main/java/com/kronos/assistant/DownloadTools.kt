package com.kronos.assistant

import android.os.Environment
import java.io.File

sealed class ScanResult {
    object NeedsPermission : ScanResult()
    data class Items(val items: List<DownloadItem>) : ScanResult()
}

/**
 * Reads the public Downloads folder. On Android 11+ this requires the user to grant "All files access"
 * to KRONOS in system settings; without it we cannot see files that other apps downloaded.
 * "Monitoring" is a snapshot on request (partial files like .crdownload are reported as in-progress),
 * not a live background watcher.
 */
object DownloadTools {
    private fun dir(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    fun hasAllFilesAccess(): Boolean = Environment.isExternalStorageManager()

    fun scan(): ScanResult {
        if (!hasAllFilesAccess()) return ScanResult.NeedsPermission
        val files = dir().listFiles()?.filter { it.isFile }.orEmpty()
            .sortedByDescending { it.lastModified() }
            .take(50)
        return ScanResult.Items(
            files.map {
                DownloadItem(
                    name = it.name,
                    path = it.absolutePath,
                    size = it.length(),
                    modified = it.lastModified(),
                    inProgress = DownloadSafety.isInProgress(it.name),
                    risk = DownloadSafety.assess(it.name)
                )
            }
        )
    }

    /** Deletes a single file, only if it sits directly inside Downloads. Callers must have confirmation first. */
    fun delete(item: DownloadItem): Boolean = try {
        val f = File(item.path).canonicalFile
        f.parentFile == dir().canonicalFile && f.isFile && f.delete()
    } catch (e: Exception) {
        false
    }
}
