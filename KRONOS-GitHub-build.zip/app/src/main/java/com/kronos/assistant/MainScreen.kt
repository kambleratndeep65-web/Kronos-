package com.kronos.assistant

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MainScreen(
    engine: KronosEngine,
    micGranted: Boolean,
    onRequestMic: () -> Unit,
    onOrbTap: () -> Unit,
    onWakeToggle: (Boolean) -> Unit,
    onSettings: () -> Unit
) {
    val ui by engine.ui.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.size - 1)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(KColors.Bg)
            .systemBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "K R O N O S", color = KColors.Cyan, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = onSettings, border = BorderStroke(1.dp, KColors.CyanDim)) {
                Text("SETTINGS", color = KColors.Cyan, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusChip("NET", if (ui.internet) "ONLINE" else "OFFLINE", if (ui.internet) KColors.Green else KColors.Red)
            when (ui.ai) {
                AiStatus.OK -> StatusChip("AI", "CONNECTED", KColors.Green)
                AiStatus.NO_KEY -> StatusChip("AI", "NO KEY", KColors.Amber)
                AiStatus.ERROR -> StatusChip("AI", "ERROR", KColors.Red)
                AiStatus.UNKNOWN -> StatusChip("AI", "UNTESTED", KColors.Amber)
            }
            StatusChip("WAKE", if (ui.wakeActive) "ON" else "OFF", if (ui.wakeActive) KColors.Cyan else KColors.Muted)
        }

        if (!micGranted) {
            Spacer(Modifier.height(8.dp))
            Surface(color = KColors.Panel, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, KColors.Amber)) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        "KRONOS needs the microphone to hear you. It listens only after you tap the orb " +
                            "(or while you have switched Wake listening on, which shows a notification).",
                        color = KColors.Text, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onRequestMic) { Text("Allow microphone") }
                }
            }
        }

        Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
            Orb(ui.phase, onOrbTap)
        }
        Text(
            phaseLabel(ui.phase), color = KColors.Cyan, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        if (ui.partial.isNotBlank()) {
            Text(
                ui.partial, color = KColors.Muted, fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
        }

        ui.notice?.let { n ->
            Spacer(Modifier.height(6.dp))
            Text(
                n + "  (tap to dismiss)", color = KColors.Amber, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().clickable { engine.dismissNotice() }
            )
        }
        if (!ui.hindiVoiceOk) {
            Text(
                "Hindi voice not installed on this phone: Hindi replies may sound wrong. See Settings.",
                color = KColors.Amber, fontSize = 12.sp
            )
        }

        ui.pendingConfirm?.let { q ->
            Spacer(Modifier.height(6.dp))
            Surface(color = KColors.Panel, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, KColors.Amber)) {
                Column(Modifier.padding(12.dp)) {
                    Text(q, color = KColors.Text, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { engine.submitText("yes") }) { Text("YES") }
                        OutlinedButton(onClick = { engine.submitText("no") }) { Text("NO") }
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(ui.messages) { MessageBubble(it) }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Wake phrase: \"Hello KRONOS\"", color = KColors.Text, fontSize = 14.sp)
                Text(
                    "Runs a visible background service, uses extra battery, and your phone's battery manager may stop it.",
                    color = KColors.Muted, fontSize = 11.sp
                )
            }
            Switch(checked = ui.wakeActive, onCheckedChange = onWakeToggle)
        }
    }
}

private fun phaseLabel(p: Phase) = when (p) {
    Phase.IDLE -> "TAP THE ORB TO SPEAK"
    Phase.LISTENING -> "LISTENING..."
    Phase.THINKING -> "THINKING..."
    Phase.SPEAKING -> "SPEAKING..."
    Phase.WAKE_STANDBY -> "STANDING BY: SAY \"HELLO KRONOS\""
}

@Composable
private fun StatusChip(name: String, value: String, color: Color) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(KColors.Panel)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text("$name $value", color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MessageBubble(m: Msg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (m.fromUser) KColors.CyanDim.copy(alpha = 0.35f) else KColors.Panel,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (m.fromUser) KColors.Cyan.copy(alpha = 0.5f) else KColors.CyanDim)
        ) {
            Text(m.text, color = KColors.Text, fontSize = 14.sp, modifier = Modifier.padding(10.dp))
        }
    }
}

@Composable
private fun Orb(phase: Phase, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val angle by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "angle"
    )
    val pulse by t.animateFloat(
        initialValue = 0.93f, targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val busy = phase == Phase.LISTENING || phase == Phase.THINKING || phase == Phase.SPEAKING
    val color = when (phase) {
        Phase.LISTENING -> KColors.Cyan
        Phase.THINKING -> KColors.Amber
        Phase.SPEAKING -> KColors.Green
        Phase.WAKE_STANDBY -> KColors.CyanDim
        Phase.IDLE -> KColors.CyanDim
    }
    Box(Modifier.size(210.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val s = if (busy) pulse else 1f
            drawCircle(color.copy(alpha = 0.10f), radius = r * 0.62f * s, center = c)
            drawCircle(color, radius = r * 0.50f * s, center = c, style = Stroke(3.dp.toPx()))
            drawArc(
                color, startAngle = angle, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(c.x - r * 0.78f, c.y - r * 0.78f), size = Size(r * 1.56f, r * 1.56f),
                style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color.copy(alpha = 0.6f), startAngle = -angle * 1.5f, sweepAngle = 60f, useCenter = false,
                topLeft = Offset(c.x - r * 0.92f, c.y - r * 0.92f), size = Size(r * 1.84f, r * 1.84f),
                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
            )
            for (i in 0 until 48) {
                val a = Math.toRadians((i * 7.5f + angle * 0.2f).toDouble())
                val r1 = r * 0.96f
                val r2 = r * (if (i % 4 == 0) 0.89f else 0.93f)
                drawLine(
                    color.copy(alpha = 0.5f),
                    Offset(c.x + (cos(a) * r1).toFloat(), c.y + (sin(a) * r1).toFloat()),
                    Offset(c.x + (cos(a) * r2).toFloat(), c.y + (sin(a) * r2).toFloat()),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
        }
        Text(
            when (phase) {
                Phase.IDLE, Phase.WAKE_STANDBY -> "TAP"
                Phase.LISTENING -> "LIVE"
                Phase.THINKING -> "..."
                Phase.SPEAKING -> "KRONOS"
            },
            color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold
        )
    }
}
