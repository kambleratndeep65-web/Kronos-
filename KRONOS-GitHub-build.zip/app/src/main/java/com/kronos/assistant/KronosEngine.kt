package com.kronos.assistant

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING, WAKE_STANDBY }
enum class AiStatus { UNKNOWN, NO_KEY, OK, ERROR }

data class Msg(val fromUser: Boolean, val text: String, val ts: Long = System.currentTimeMillis())

data class UiState(
    val phase: Phase = Phase.IDLE,
    val messages: List<Msg> = emptyList(),
    val partial: String = "",
    val internet: Boolean = false,
    val ai: AiStatus = AiStatus.UNKNOWN,
    val aiDetail: String = "",
    val pendingConfirm: String? = null,
    val notice: String? = null,
    val wakeActive: Boolean = false,
    val hindiVoiceOk: Boolean = true
)

/**
 * Single brain of the app: listens (SpeechRecognizer), decides (local commands first, AI otherwise),
 * speaks (TextToSpeech). All methods must be called on the main thread.
 */
class KronosEngine private constructor(private val app: Context) {

    companion object {
        @Volatile private var inst: KronosEngine? = null
        fun get(ctx: Context): KronosEngine =
            inst ?: synchronized(this) { inst ?: KronosEngine(ctx.applicationContext).also { inst = it } }
    }

    val prefs = Prefs(app)
    private val ai = AiClient(prefs)
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    /** Set by MainActivity: true while KRONOS is on screen (needed to open other apps directly). */
    @Volatile var foreground = false

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var conversation = false
    private var wake = false
    private var silentRounds = 0
    private var errRetries = 0
    private var pending: PendingAction? = null
    private var lastScan: List<DownloadItem> = emptyList()
    private var aiJob: Job? = null

    private class PendingAction(val prompt: String, val run: () -> String)

    init {
        setupTts()
        watchNetwork()
        refreshAiStatus()
    }

    // ---------------------------------------------------------------- public controls

    fun toggleConversation() {
        if (conversation) stopListening() else startConversation()
    }

    fun startConversation() {
        conversation = true
        silentRounds = 0
        doListen()
    }

    fun stopListening() {
        conversation = false
        aiJob?.cancel()
        pending = null
        recognizer?.cancel()
        tts?.stop()
        _ui.update { it.copy(partial = "", pendingConfirm = null) }
        if (wake) doListen() else setPhase(Phase.IDLE)
    }

    fun startWake() {
        wake = true
        _ui.update { it.copy(wakeActive = true) }
        if (!conversation) doListen()
    }

    fun stopWake() {
        wake = false
        _ui.update { it.copy(wakeActive = false) }
        if (!conversation) {
            recognizer?.cancel()
            setPhase(Phase.IDLE)
        }
    }

    fun submitText(text: String) = process(text)

    fun dismissNotice() = _ui.update { it.copy(notice = null) }

    fun showNotice(text: String) = notice(text)

    fun refreshAiStatus() {
        if (prefs.apiKey.isBlank()) setAi(AiStatus.NO_KEY, "No API key") else if (_ui.value.ai == AiStatus.NO_KEY) setAi(AiStatus.UNKNOWN, "")
    }

    fun testAi() {
        if (prefs.apiKey.isBlank()) { setAi(AiStatus.NO_KEY, "No API key"); return }
        setAi(AiStatus.UNKNOWN, "Testing...")
        scope.launch {
            when (val r = ai.ping()) {
                is AiResult.Ok -> setAi(AiStatus.OK, "Connected. Reply: ${r.text.take(40)}")
                is AiResult.Err -> setAi(if (r.kind == ErrKind.NO_KEY) AiStatus.NO_KEY else AiStatus.ERROR, r.message)
            }
        }
    }

    // ---------------------------------------------------------------- listening

    private fun hasMic() =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun active() = conversation || wake

    private fun buildIntent(): Intent {
        val tag = if (prefs.language == "en") "en-IN" else "hi-IN"
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            if (prefs.language == "mixed") {
                putExtra(RecognizerIntent.EXTRA_ADDITIONAL_LANGUAGES, arrayOf("en-IN"))
            }
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, prefs.preferOffline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
    }

    private fun doListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            notice("Speech recognition isn't available on this phone (no recognition service installed).")
            stopEverything(); return
        }
        if (!hasMic()) {
            notice("Microphone permission is needed. Open KRONOS and allow it.")
            stopEverything(); return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(app).also { it.setRecognitionListener(listener) }
        recognizer?.startListening(buildIntent())
        setPhase(if (!conversation && wake) Phase.WAKE_STANDBY else Phase.LISTENING)
    }

    private fun relisten(delayMs: Long) {
        main.postDelayed({ if (active()) doListen() }, delayMs)
    }

    private fun stopEverything() {
        conversation = false
        wake = false
        recognizer?.cancel()
        _ui.update { it.copy(wakeActive = false, partial = "") }
        setPhase(Phase.IDLE)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            if (!conversation) return // never display what is heard while only waiting for the wake phrase
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            _ui.update { it.copy(partial = t) }
        }

        override fun onError(error: Int) = handleRecError(error)

        override fun onResults(results: Bundle?) {
            onHeard(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty())
        }
    }

    private fun handleRecError(error: Int) {
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                if (wake && !conversation) {
                    relisten(300)
                } else {
                    silentRounds++
                    _ui.update { it.copy(partial = "") }
                    if (silentRounds >= 2) {
                        conversation = false
                        silentRounds = 0
                        if (wake) relisten(300) else setPhase(Phase.IDLE)
                    } else relisten(200)
                }
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                if (++errRetries > 3) { notice("Speech recognizer keeps failing. Try again."); stopEverything() }
                else relisten(800)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                notice("Microphone permission was denied."); stopEverything()
            }
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                notice("Speech recognition needs internet, or an offline language pack for Hindi/English in Google's app settings.")
                stopEverything()
            }
            else -> { notice("Speech recognition error ($error)."); stopEverything() }
        }
    }

    private fun onHeard(alternatives: List<String>) {
        errRetries = 0
        if (alternatives.none { it.isNotBlank() }) { handleRecError(SpeechRecognizer.ERROR_NO_MATCH); return }

        if (wake && !conversation) {
            val m = alternatives.map { WakeMatcher.match(it) }.firstOrNull { it.matched }
            if (m == null) { relisten(100); return }
            conversation = true
            silentRounds = 0
            if (m.remainder.isNotBlank()) process(m.remainder)
            else reply(if (prefs.language == "en") "Yes, I'm listening." else "जी, बोलिए।")
            return
        }
        silentRounds = 0
        process(alternatives.first { it.isNotBlank() }.trim())
    }

    // ---------------------------------------------------------------- deciding

    private fun process(text: String) {
        addMsg(true, text)
        _ui.update { it.copy(partial = "") }
        val hindi = LangDetect.isHindi(text)
        val cmd = CommandRouter.parse(text)

        pending?.let { p ->
            pending = null
            _ui.update { it.copy(pendingConfirm = null) }
            when (cmd) {
                Command.Yes -> { reply(p.run()); return }
                Command.No -> { reply(if (hindi) "ठीक है, रद्द कर दिया।" else "Okay, cancelled."); return }
                else -> Unit // anything else cancels the pending action and is handled normally
            }
        }

        when (cmd) {
            Command.Stop -> {
                conversation = false // must be cleared before reply() so we don't re-listen after speaking
                reply(if (hindi) "ठीक है, मैं सुनना बंद करता हूँ।" else "Okay, I'll stop listening.")
            }
            Command.Yes, Command.No -> reply(if (hindi) "किस बात के लिए?" else "Confirm what? Nothing is waiting for an answer.")
            Command.Time -> reply(Speakables.timeText(LocalTime.now(), hindi))
            Command.Date -> reply(Speakables.dateText(LocalDate.now(), hindi))
            Command.Notifications -> {
                if (!KronosNotificationListener.isEnabled(app)) {
                    reply(
                        if (hindi) "नोटिफिकेशन एक्सेस बंद है। KRONOS की सेटिंग्स में चालू कीजिए। मैं सिर्फ़ आपके कहने पर पढ़ता हूँ।"
                        else "Notification access is off. Turn it on in KRONOS settings. I only read notifications when you ask."
                    )
                } else reply(Speakables.notificationsText(KronosNotificationListener.activeItems(), hindi))
            }
            Command.Downloads, Command.ScanDownloads -> scanDownloads(hindi)
            is Command.Delete -> handleDelete(cmd.query, hindi)
            is Command.OpenApp -> {
                val found = findApp(cmd.name)
                if (found != null) reply(launch(found.first, found.second, hindi))
                else if (cmd.name.split(" ").size > 3) askAi(hindi)
                else reply(if (hindi) "मुझे ${cmd.name} नाम का ऐप नहीं मिला।" else "I couldn't find an app called ${cmd.name}.")
            }
            is Command.Ask -> askAi(hindi)
        }
    }

    private fun askAi(hindi: Boolean) {
        setPhase(Phase.THINKING)
        val history = _ui.value.messages.takeLast(10).map { ChatMsg(if (it.fromUser) "user" else "assistant", it.text) }
        aiJob?.cancel()
        aiJob = scope.launch {
            when (val r = ai.chat(history)) {
                is AiResult.Ok -> { setAi(AiStatus.OK, "Last reply OK"); reply(r.text) }
                is AiResult.Err -> {
                    setAi(if (r.kind == ErrKind.NO_KEY) AiStatus.NO_KEY else AiStatus.ERROR, r.message)
                    reply(aiErrorText(r.kind, hindi))
                }
            }
        }
    }

    private fun aiErrorText(kind: ErrKind, hindi: Boolean): String = when (kind) {
        ErrKind.NO_KEY -> if (hindi) "AI के लिए सेटिंग्स में एक मुफ़्त API की डालिए।" else "I need a free AI key. Open Settings and paste one in."
        ErrKind.NO_INTERNET -> if (hindi) "मैं AI सेवा तक नहीं पहुँच पा रहा, इंटरनेट जाँचिए।" else "I can't reach the AI service. Please check your internet."
        ErrKind.AUTH -> if (hindi) "AI सेवा ने आपकी API की स्वीकार नहीं की, सेटिंग्स में जाँचिए।" else "The AI service rejected the key. Please check it in Settings."
        ErrKind.RATE_LIMIT -> if (hindi) "मुफ़्त AI की सीमा अभी पूरी हो गई है, थोड़ी देर बाद कोशिश कीजिए।" else "The free AI limit has been reached for now. Try again in a minute, or tomorrow."
        ErrKind.SERVER, ErrKind.PARSE -> if (hindi) "AI सेवा में समस्या आई, फिर कोशिश कीजिए।" else "The AI service had a problem. Please try again."
    }

    // ---------------------------------------------------------------- phone features

    private fun findApp(name: String): Pair<String, Intent>? {
        val pm = app.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(query, PackageManager.ResolveInfoFlags.of(0))
        } else {
            pm.queryIntentActivities(query, 0)
        }
        val labels = apps.map { it.loadLabel(pm).toString() }
        val idx = AppMatch.bestMatch(name, labels) ?: return null
        val launch = pm.getLaunchIntentForPackage(apps[idx].activityInfo.packageName) ?: return null
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return labels[idx] to launch
    }

    private fun launch(label: String, intent: Intent, hindi: Boolean): String {
        if (foreground) {
            return try {
                app.startActivity(intent)
                if (hindi) "$label खोल रहा हूँ।" else "Opening $label."
            } catch (e: Exception) {
                if (hindi) "$label नहीं खुल पाया।" else "I couldn't open $label."
            }
        }
        // Android blocks apps from starting other apps from the background; offer a tap instead.
        if (!NotificationManagerCompat.from(app).areNotificationsEnabled()) {
            return if (hindi) "Android बैकग्राउंड से ऐप खोलने नहीं देता। KRONOS खोलकर दोबारा कहिए।"
            else "Android blocks opening apps from the background. Open KRONOS and ask again, or allow notifications."
        }
        Channels.ensure(app)
        val pi = PendingIntent.getActivity(app, label.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(app, Channels.ACTIONS)
            .setSmallIcon(R.drawable.ic_kronos)
            .setContentTitle("Open $label")
            .setContentText("Tap to open")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(app).notify(label.hashCode(), n) } catch (e: SecurityException) { /* permission revoked */ }
        return if (hindi) "Android बैकग्राउंड से ऐप नहीं खोलने देता, इसलिए $label के लिए नोटिफिकेशन भेजा है, उस पर टैप कीजिए।"
        else "Android doesn't allow opening apps from the background, so I posted a notification. Tap it to open $label."
    }

    private fun scanDownloads(hindi: Boolean) {
        setPhase(Phase.THINKING)
        scope.launch {
            when (val res = withContext(Dispatchers.IO) { DownloadTools.scan() }) {
                is ScanResult.NeedsPermission -> {
                    notice("Downloads scan needs \"All files access\". Enable it in KRONOS Settings.")
                    reply(
                        if (hindi) "डाउनलोड्स देखने के लिए सेटिंग्स में ऑल फाइल्स एक्सेस की अनुमति दीजिए।"
                        else "To look at your Downloads folder, please grant All files access in KRONOS settings."
                    )
                }
                is ScanResult.Items -> { lastScan = res.items; reply(Speakables.downloadSummary(res.items, hindi)) }
            }
        }
    }

    private fun handleDelete(query: String, hindi: Boolean) {
        if (lastScan.isEmpty()) {
            reply(if (hindi) "पहले मुझसे डाउनलोड्स स्कैन करवाइए, फिर बताइए कौन सी फ़ाइल हटानी है."
            else "Ask me to scan your downloads first, then tell me which file to delete.")
            return
        }
        val q = query.lowercase()
        val wantsRisky = Regex("risky|suspicious|unsafe|dangerous|खतरनाक|संदिग्ध").containsMatchIn(q)
        val target = if (wantsRisky) lastScan.filter { it.risk.level != RiskLevel.SAFE }.maxByOrNull { it.risk.level.ordinal }
        else lastScan.firstOrNull { it.name.lowercase().contains(q) }
        if (target == null) {
            reply(if (hindi) "$query से मेल खाती कोई फ़ाइल नहीं मिली।" else "I couldn't match \"$query\" to a file from the last scan.")
            return
        }
        val prompt = if (hindi) "${target.name} हटानी है? यह वापस नहीं आएगी। पक्का करने के लिए हाँ बोलिए, रद्द करने के लिए नहीं।"
        else "Delete ${target.name}? This can't be undone. Say yes to confirm or no to cancel."
        pending = PendingAction(prompt) {
            if (DownloadTools.delete(target)) {
                lastScan = lastScan - target
                if (hindi) "${target.name} हटा दी।" else "Deleted ${target.name}."
            } else if (hindi) "वह फ़ाइल नहीं हटा सका।" else "I couldn't delete that file."
        }
        _ui.update { it.copy(pendingConfirm = prompt) }
        reply(prompt)
    }

    // ---------------------------------------------------------------- speaking

    private fun setupTts() {
        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { onSpeechFinished() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { onSpeechFinished() } }
                })
                val hi = tts?.isLanguageAvailable(Locale("hi", "IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                _ui.update { it.copy(hindiVoiceOk = hi >= TextToSpeech.LANG_AVAILABLE) }
            } else {
                notice("Text-to-speech engine failed to start, so I can't speak replies.")
            }
        }
    }

    private fun reply(text: String) {
        addMsg(false, text)
        speak(text)
    }

    private fun speak(text: String) {
        val clean = text.replace(Regex("[*#_`>]"), "").trim()
        if (!ttsReady || clean.isEmpty()) { onSpeechFinished(); return }
        val loc = if (LangDetect.replyIsHindi(clean)) Locale("hi", "IN") else Locale("en", "IN")
        val r = tts?.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            notice("This phone has no ${loc.displayLanguage} voice installed. Add it in Settings > Text-to-speech.")
        }
        tts?.setSpeechRate(prefs.speechRate)
        setPhase(Phase.SPEAKING)
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "kronos-${System.nanoTime()}")
    }

    private fun onSpeechFinished() {
        when {
            conversation -> doListen()
            wake -> doListen()
            else -> setPhase(Phase.IDLE)
        }
    }

    // ---------------------------------------------------------------- state helpers

    private fun setPhase(p: Phase) = _ui.update { it.copy(phase = p) }
    private fun setAi(s: AiStatus, detail: String) = _ui.update { it.copy(ai = s, aiDetail = detail) }
    private fun notice(t: String) = _ui.update { it.copy(notice = t) }
    private fun addMsg(fromUser: Boolean, text: String) =
        _ui.update { it.copy(messages = (it.messages + Msg(fromUser, text)).takeLast(200)) }

    private fun watchNetwork() {
        val cm = app.getSystemService(ConnectivityManager::class.java)
        fun online(): Boolean {
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }
        _ui.update { it.copy(internet = online()) }
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { _ui.update { it.copy(internet = online()) } }
            override fun onLost(network: Network) { _ui.update { it.copy(internet = false) } }
            override fun onCapabilitiesChanged(network: Network, nc: NetworkCapabilities) {
                _ui.update { it.copy(internet = online()) }
            }
        })
    }
}
