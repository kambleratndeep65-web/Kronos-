package com.kronos.assistant

enum class RiskLevel { SAFE, CAUTION, HIGH }

data class Risk(val level: RiskLevel, val reasons: List<String>)

data class DownloadItem(
    val name: String,
    val path: String,
    val size: Long,
    val modified: Long,
    val inProgress: Boolean,
    val risk: Risk
)

/**
 * Filename-only heuristics. This is NOT an antivirus: it cannot see inside a file, and a clean verdict
 * does not mean a file is safe. It only flags well-known warning signs in the name/type.
 */
object DownloadSafety {
    private val doubleExtension = Regex(
        ".*\\.(pdf|jpe?g|png|gif|docx?|xlsx?|pptx?|txt|mp[34]|mkv|zip)\\.(apk|exe|scr|bat|cmd|com|js|vbs|jar|msi|ps1)$"
    )
    private val pirateHints = Regex("(crack|keygen|patched|mod[ _-]?apk|hack|cheat|nulled)")
    private val inProgressExt = setOf("crdownload", "part", "tmp", "download", "opdownload")

    fun isInProgress(name: String): Boolean = name.lowercase().substringAfterLast('.', "") in inProgressExt

    fun assess(name: String): Risk {
        val lower = name.lowercase().trim()
        val reasons = mutableListOf<String>()
        var level = RiskLevel.SAFE
        fun bump(l: RiskLevel, why: String) {
            reasons += why
            if (l.ordinal > level.ordinal) level = l
        }

        if (name.contains('‮')) bump(RiskLevel.HIGH, "hidden character that disguises the real file type")
        if (doubleExtension.matches(lower)) bump(RiskLevel.HIGH, "double extension: looks like a document but is a program")

        when (lower.substringAfterLast('.', "")) {
            "exe", "scr", "bat", "cmd", "com", "msi", "vbs", "ps1", "jar", "js" ->
                bump(RiskLevel.HIGH, "program or script file type that a phone normally doesn't need")
            "apk", "apks", "xapk", "apkm" ->
                bump(RiskLevel.CAUTION, "installable app file; install only if it came from a source you trust")
        }
        if (pirateHints.containsMatchIn(lower)) bump(RiskLevel.CAUTION, "name suggests pirated or modified software")
        return Risk(level, reasons)
    }
}
