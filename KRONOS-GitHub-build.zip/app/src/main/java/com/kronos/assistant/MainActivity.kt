package com.kronos.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var engine: KronosEngine
    private val micGranted = mutableStateOf(false)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            micGranted.value = hasMic()
        }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        // Microphone is needed to hear you; notifications are needed for the wake-listening indicator
        // and tap-to-open prompts. The system dialog explains each one.
        permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
    }

    private fun setWake(on: Boolean) {
        if (on) {
            if (!hasMic()) { requestPerms(); return }
            ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
        } else {
            stopService(Intent(this, WakeService::class.java))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = KronosEngine.get(this)
        micGranted.value = hasMic()
        setContent { KronosTheme { Root() } }
    }

    override fun onStart() {
        super.onStart()
        engine.foreground = true
        micGranted.value = hasMic()
    }

    override fun onStop() {
        engine.foreground = false
        super.onStop()
    }

    @Composable
    private fun Root() {
        var screen by rememberSaveable { mutableStateOf("main") }
        if (screen == "settings") {
            BackHandler { screen = "main" }
            SettingsScreen(engine, onBack = { screen = "main" })
        } else {
            MainScreen(
                engine = engine,
                micGranted = micGranted.value,
                onRequestMic = { requestPerms() },
                onOrbTap = { if (hasMic()) engine.toggleConversation() else requestPerms() },
                onWakeToggle = { setWake(it) },
                onSettings = { screen = "settings" }
            )
        }
    }
}
