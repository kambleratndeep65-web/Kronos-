package com.kronos.assistant

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat

/**
 * Lets KRONOS read the notifications currently in the shade, ONLY when the user asks and has enabled
 * notification access. Nothing is stored or uploaded; each request reads the live list.
 */
class KronosNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    private fun toItem(sbn: StatusBarNotification): NotifItem? {
        if (sbn.packageName == packageName || sbn.isOngoing) return null
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return null
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        return NotifItem(label, title, text, sbn.postTime)
    }

    companion object {
        @Volatile
        private var instance: KronosNotificationListener? = null

        fun isEnabled(ctx: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

        fun activeItems(): List<NotifItem> {
            val svc = instance ?: return emptyList()
            return try {
                svc.activeNotifications.orEmpty().mapNotNull { svc.toItem(it) }.sortedByDescending { it.time }
            } catch (e: Exception) {
                emptyList()
            }
        }

        @Suppress("unused")
        fun componentName(ctx: Context) = ComponentName(ctx, KronosNotificationListener::class.java)
    }
}
