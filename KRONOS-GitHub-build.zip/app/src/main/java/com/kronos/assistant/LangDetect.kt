package com.kronos.assistant

/** Tiny script/keyword heuristics to pick the reply language and TTS voice. Not a real language-ID model. */
object LangDetect {
    private val hinglishMarkers = setOf(
        "kya", "hai", "hain", "nahi", "nahin", "mujhe", "mera", "meri", "aap", "tum", "batao",
        "bataiye", "karo", "kaise", "kyun", "kyu", "aaj", "kal", "abhi", "thoda", "bahut",
        "acha", "achha", "theek", "samay", "baje", "liye", "wala", "kholo", "chahiye", "hota"
    )

    private fun devanagariCount(s: String) = s.count { it in 'ऀ'..'ॿ' }

    /** True if the user's utterance looks Hindi: Devanagari script, or Roman-script Hindi (Hinglish) markers. */
    fun isHindi(s: String): Boolean {
        if (devanagariCount(s) >= 2) return true
        val words = s.lowercase().split(Regex("[^a-z]+"))
        return words.count { it in hinglishMarkers } >= 2
    }

    /** True if a reply is mostly Devanagari, so it should be spoken with the Hindi voice. */
    fun replyIsHindi(s: String): Boolean {
        val letters = s.count { it.isLetter() }
        if (letters == 0) return false
        return devanagariCount(s) * 10 >= letters * 3
    }
}
