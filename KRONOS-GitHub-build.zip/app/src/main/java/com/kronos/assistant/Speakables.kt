package com.kronos.assistant

import java.time.LocalDate
import java.time.LocalTime

data class NotifItem(val app: String, val title: String, val text: String, val time: Long)

/** Builds the sentences KRONOS speaks for locally handled commands. Pure functions, easy to test. */
object Speakables {
    private val daysEn = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
    private val daysHi = listOf("सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार", "रविवार")
    private val monthsEn = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    private val monthsHi = listOf(
        "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
        "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
    )
    private val otp = Regex("(?i)(?<!\\p{L})(otp|one[- ]time|verification code)(?!\\p{L})")

    fun timeText(t: LocalTime, hindi: Boolean): String {
        val h = t.hour
        val m = t.minute
        val h12 = if (h % 12 == 0) 12 else h % 12
        return if (hindi) {
            val part = when {
                h < 12 -> "सुबह"
                h < 16 -> "दोपहर"
                h < 20 -> "शाम"
                else -> "रात"
            }
            if (m == 0) "अभी $part के $h12 बजे हैं।" else "अभी $part के $h12 बजकर $m मिनट हुए हैं।"
        } else {
            "It's $h12:${m.toString().padStart(2, '0')} ${if (h < 12) "AM" else "PM"}."
        }
    }

    fun dateText(d: LocalDate, hindi: Boolean): String {
        val di = d.dayOfWeek.value - 1
        val mi = d.monthValue - 1
        return if (hindi) "आज ${d.dayOfMonth} ${monthsHi[mi]} ${d.year}, ${daysHi[di]} है।"
        else "Today is ${daysEn[di]}, ${d.dayOfMonth} ${monthsEn[mi]} ${d.year}."
    }

    fun notificationsText(items: List<NotifItem>, hindi: Boolean): String {
        if (items.isEmpty()) {
            return if (hindi) "कोई हाल की नोटिफिकेशन नहीं मिली।" else "I don't see any recent notifications."
        }
        val intro = if (hindi) "आपकी ${items.size} नोटिफिकेशन हैं। " else "You have ${items.size} recent notifications. "
        val parts = items.take(5).map { n ->
            val body = listOf(n.title, n.text).filter { it.isNotBlank() }.joinToString(": ").take(120)
            if (otp.containsMatchIn(body)) {
                if (hindi) "${n.app}: वेरिफ़िकेशन कोड वाला मैसेज, सुरक्षा के लिए पढ़ा नहीं जा रहा।"
                else "${n.app}: a verification code message, contents hidden for your safety."
            } else "${n.app}: $body"
        }
        return intro + parts.joinToString(" ")
    }

    fun downloadSummary(items: List<DownloadItem>, hindi: Boolean): String {
        if (items.isEmpty()) {
            return if (hindi) "डाउनलोड्स फ़ोल्डर में कोई फ़ाइल नहीं मिली।" else "Your Downloads folder has no files."
        }
        val inProgress = items.count { it.inProgress }
        val flagged = items.filter { it.risk.level != RiskLevel.SAFE }
            .sortedByDescending { it.risk.level.ordinal }
        return if (hindi) {
            val head = "डाउनलोड्स में ${items.size} फ़ाइलें हैं, ${inProgress} अभी डाउनलोड हो रही हैं। "
            if (flagged.isEmpty()) head + "नाम देखकर कुछ संदिग्ध नहीं लगा, लेकिन यह एंटीवायरस जांच नहीं है।"
            else head + "${flagged.size} फ़ाइलों पर ध्यान दें: " +
                flagged.take(3).joinToString("; ") { it.name } +
                "। किसी को हटाने के लिए डिलीट और फ़ाइल का नाम बोलिए, मैं पहले पूछूंगा।"
        } else {
            val head = "I found ${items.size} files in Downloads, $inProgress still downloading. "
            if (flagged.isEmpty()) {
                head + "Nothing looks suspicious by name, but this is only a filename check, not an antivirus scan."
            } else {
                head + "${flagged.size} need attention: " +
                    flagged.take(3).joinToString("; ") { "${it.name}, ${it.risk.reasons.first()}" } +
                    ". Say delete and a file name to remove one. I'll ask you to confirm first."
            }
        }
    }
}
