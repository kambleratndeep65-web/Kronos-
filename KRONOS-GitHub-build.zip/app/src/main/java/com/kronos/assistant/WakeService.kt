package com.kronos.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat

object Channels {
    const val WAKE = "kronos_wake"
    const val ACTIONS = "kronos_actions"

    fun ensure(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(WAKE, "KRONOS listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(ACTIONS, "KRONOS actions", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

/**
 * Optional "Hello KRONOS" standby. Android does not let normal apps use the system hotword hardware,
 * so this is a visible foreground service that runs the speech recognizer in a loop and checks the
 * transcript for the wake phrase. It always shows a persistent notification with a Stop button, uses
 * noticeably more battery, and the phone maker's battery manager may still stop it.
 */
class WakeService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        Channels.ensure(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, Channels.WAKE)
            .setSmallIcon(R.drawable.ic_kronos)
            .setContentTitle("KRONOS is listening for \"Hello KRONOS\"")
            .setContentText("The microphone is in use while this is shown.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        KronosEngine.get(this).startWake()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        KronosEngine.get(this).stopWake()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.kronos.assistant.STOP_WAKE"
        private const val NOTIF_ID = 42
    }
}
