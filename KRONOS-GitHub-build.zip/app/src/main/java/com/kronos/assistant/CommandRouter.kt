package com.kronos.assistant

/** What the user asked for. Everything except [Ask] is handled locally on the phone, never sent to the AI. */
sealed class Command {
    object Time : Command()
    object Date : Command()
    object Notifications : Command()
    object Downloads : Command()
    object ScanDownloads : Command()
    object Stop : Command()
    object Yes : Command()
    object No : Command()
    data class OpenApp(val name: String) : Command()
    data class Delete(val query: String) : Command()
    data class Ask(val text: String) : Command()
}

object CommandRouter {

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[?!,।]"), " ").replace(Regex("\\s+"), " ").trim().trimEnd('.')

    private val yes = setOf(
        "yes", "yeah", "yep", "yup", "confirm", "confirmed", "sure", "do it",
        "haan", "han", "haa", "ha", "haan karo", "haan kar do", "kar do",
        "हाँ", "हां", "हा", "जी हाँ", "जी हां", "हाँ कर दो", "हां कर दो", "कर दो"
    )
    private val no = setOf(
        "no", "nope", "cancel", "don't", "do not", "nahi", "nahin", "nahi karo", "na",
        "नहीं", "नहीं करो", "मत करो", "रहने दो", "cancel karo", "रद्द करो"
    )
    private val stopPhrases = listOf(
        "stop listening", "go to sleep", "bye kronos", "goodbye kronos", "good night kronos",
        "sunna band", "सुनना बंद", "बाय क्रोनोस"
    )
    private val timePhrases = listOf(
        "what time is it", "what's the time", "what is the time", "tell me the time", "current time",
        "time kya", "samay kya", "kitne baje", "कितने बजे", "टाइम क्या", "समय क्या",
        "time batao", "टाइम बताओ", "समय बताओ", "क्या समय", "क्या टाइम"
    )
    private val datePhrases = listOf(
        "what's the date", "what is the date", "today's date", "what day is it", "which day",
        "aaj ki date", "aaj kya date", "aaj ki tarikh", "tarikh kya", "आज की तारीख", "तारीख क्या",
        "date batao", "डेट बताओ", "आज कौन सा दिन"
    )
    private val scanWords = setOf(
        "scan", "check", "safe", "suspicious", "virus", "unsafe",
        "जांच", "चेक", "सुरक्षित", "स्कैन", "संदिग्ध"
    )
    private val listWords = setOf(
        "show", "list", "my", "status", "progress", "dikhao", "batao",
        "दिखाओ", "बताओ", "मेरे", "मेरी", "स्टेटस"
    )

    private val deletePrefix = Regex("^(?:please )?(?:delete|remove)\\s+(.+)$")
    private val deleteSuffix = Regex("^(.+?)\\s+(?:delete karo|delete kar do|delete kar|hatao|हटाओ|डिलीट करो|हटा दो)$")
    private val openPrefix = Regex("^(?:please )?(?:open|launch|start)\\s+(.+)$")
    private val openHindiPrefix = Regex("^(?:open karo|ओपन करो)\\s+(.+)$")
    private val openSuffix = Regex(
        "^(.+?)\\s+(?:kholo|khol do|khol dijiye|kholiye|open karo|open kar do|chalu karo|start karo|" +
            "खोलो|खोल दो|खोलिए|खोल दीजिए|चालू करो|ओपन करो)$"
    )

    fun parse(raw: String): Command {
        val t = norm(raw)
        if (t.isEmpty()) return Command.Ask(raw.trim())
        if (t in yes) return Command.Yes
        if (t in no) return Command.No
        if (t == "stop" || stopPhrases.any { t.contains(it) }) return Command.Stop

        deletePrefix.matchEntire(t)?.let { return Command.Delete(it.groupValues[1].trim()) }
        deleteSuffix.matchEntire(t)?.let { return Command.Delete(it.groupValues[1].trim()) }

        openPrefix.matchEntire(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }
        openHindiPrefix.matchEntire(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }
        openSuffix.matchEntire(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }

        val tokens = t.split(" ").toSet()
        val mentionsDownloads = tokens.any { it.startsWith("download") || it.startsWith("डाउनलोड") }
        if (mentionsDownloads) {
            if (tokens.any { it in scanWords }) return Command.ScanDownloads
            if (tokens.any { it in listWords }) return Command.Downloads
        }
        if (tokens.any { it.startsWith("notification") || it.startsWith("नोटिफ") }) return Command.Notifications
        if (timePhrases.any { t.contains(it) }) return Command.Time
        if (datePhrases.any { t.contains(it) }) return Command.Date

        return Command.Ask(raw.trim())
    }
}
