package com.kronos.assistant

/** Matches a spoken app name (English or Hindi transliteration) against installed app labels. */
object AppMatch {
    private val aliases = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "कैमरा" to "camera", "सेटिंग्स" to "settings", "सेटिंग" to "settings",
        "क्रोम" to "chrome", "मैप्स" to "maps", "गूगल मैप्स" to "maps", "फोन" to "phone",
        "जीमेल" to "gmail", "कैलकुलेटर" to "calculator", "इंस्टाग्राम" to "instagram",
        "फेसबुक" to "facebook", "गैलरी" to "gallery", "घड़ी" to "clock", "संदेश" to "messages",
        "टेलीग्राम" to "telegram", "स्पॉटिफाई" to "spotify"
    )

    fun clean(query: String): String {
        var s = query.lowercase().trim()
        aliases[s]?.let { return it } // check first: "व्हाट्सएप" itself contains the filler word "एप"
        // Filler words are removed only as whole words (not when they are part of a longer word).
        s = s.replace(Regex("(?<![\\p{L}\\p{M}])(the|app|please|my|ऐप|एप)(?![\\p{L}\\p{M}])"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return aliases[s] ?: aliases.entries.firstOrNull { s.contains(it.key) }?.value ?: s
    }

    /** Index of the best matching label, or null. Order: exact, prefix, substring, label-inside-query. */
    fun bestMatch(query: String, labels: List<String>): Int? {
        val q = clean(query)
        if (q.isBlank()) return null
        val l = labels.map { it.lowercase().trim() }
        l.indexOfFirst { it == q }.takeIf { it >= 0 }?.let { return it }
        l.indices.filter { l[it].startsWith(q) }.minByOrNull { l[it].length }?.let { return it }
        l.indices.filter { l[it].contains(q) }.minByOrNull { l[it].length }?.let { return it }
        l.indices.filter { l[it].length >= 3 && q.contains(l[it]) }.maxByOrNull { l[it].length }?.let { return it }
        return null
    }
}
