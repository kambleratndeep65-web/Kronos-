package com.kronos.assistant

import android.content.Context

/**
 * Free OpenAI-compatible chat endpoints. KRONOS ships WITHOUT any key: you create your own free key
 * (no credit card needed at the time of research, Nov 2026) and paste it in Settings.
 * Model IDs below are defaults and are editable in Settings because providers rename/retire models.
 */
enum class Provider(
    val id: String,
    val label: String,
    val url: String,
    val defaultModel: String,
    val signup: String,
    val note: String
) {
    GROQ(
        "groq", "Groq",
        "https://api.groq.com/openai/v1/chat/completions",
        "llama-3.3-70b-versatile", "console.groq.com",
        "Free tier, no card. Stated limits ~30 requests/min, ~1,000/day. Prompts are not used for training per provider comparisons."
    ),
    GEMINI(
        "gemini", "Google Gemini",
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "gemini-3.6-flash", "aistudio.google.com",
        "Free tier, best Hindi quality of the three. On the free tier Google may use your prompts to improve its products."
    ),
    OPENROUTER(
        "openrouter", "OpenRouter (free models)",
        "https://openrouter.ai/api/v1/chat/completions",
        "meta-llama/llama-3.3-70b-instruct:free", "openrouter.ai",
        "Free models, no card. Roughly 20 requests/min and ~50/day without a top-up."
    );

    companion object {
        fun fromId(id: String): Provider = entries.firstOrNull { it.id == id } ?: GROQ
    }
}

/** All settings live only in this app's private storage on the phone. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("kronos_prefs", Context.MODE_PRIVATE)

    var provider: String
        get() = sp.getString("provider", Provider.GROQ.id) ?: Provider.GROQ.id
        set(v) { sp.edit().putString("provider", v).apply() }

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) { sp.edit().putString("api_key", v).apply() }

    /** Empty means "use the provider's default model". */
    var model: String
        get() = sp.getString("model", "") ?: ""
        set(v) { sp.edit().putString("model", v).apply() }

    /** "mixed" (Hindi + English), "hi" or "en". */
    var language: String
        get() = sp.getString("language", "mixed") ?: "mixed"
        set(v) { sp.edit().putString("language", v).apply() }

    var speechRate: Float
        get() = sp.getFloat("speech_rate", 1.0f)
        set(v) { sp.edit().putFloat("speech_rate", v).apply() }

    var preferOffline: Boolean
        get() = sp.getBoolean("prefer_offline", false)
        set(v) { sp.edit().putBoolean("prefer_offline", v).apply() }
}
