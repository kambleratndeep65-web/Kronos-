package com.kronos.assistant

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object KColors {
    val Bg = Color(0xFF030A12)
    val Panel = Color(0xFF0A1722)
    val Cyan = Color(0xFF00E5FF)
    val CyanDim = Color(0xFF0B6B78)
    val Amber = Color(0xFFFFB300)
    val Green = Color(0xFF00E676)
    val Red = Color(0xFFFF5252)
    val Text = Color(0xFFD6F7FF)
    val Muted = Color(0xFF6F8FA0)
}

@Composable
fun KronosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = KColors.Cyan,
            onPrimary = KColors.Bg,
            secondary = KColors.Amber,
            background = KColors.Bg,
            onBackground = KColors.Text,
            surface = KColors.Panel,
            onSurface = KColors.Text
        ),
        content = content
    )
}
