package com.kronos.assistant

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun SettingsScreen(engine: KronosEngine, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = engine.prefs
    val ui by engine.ui.collectAsStateWithLifecycle()

    var provider by remember { mutableStateOf(prefs.provider) }
    var key by remember { mutableStateOf(prefs.apiKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var language by remember { mutableStateOf(prefs.language) }
    var rate by remember { mutableFloatStateOf(prefs.speechRate) }
    var offline by remember { mutableStateOf(prefs.preferOffline) }
    val current = Provider.fromId(provider)

    fun launchSafely(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { engine.showNotice("This phone has no screen for that setting.") }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(KColors.Bg)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack, border = BorderStroke(1.dp, KColors.CyanDim)) { Text("BACK", color = KColors.Cyan) }
            Spacer(Modifier.padding(start = 12.dp))
            Text("SETTINGS", color = KColors.Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Section("AI brain (free)")
        Provider.entries.forEach { p ->
            Row(
                Modifier.fillMaxWidth().selectable(selected = provider == p.id, role = Role.RadioButton) {
                    provider = p.id; prefs.provider = p.id; model = ""; prefs.model = ""; engine.refreshAiStatus()
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = provider == p.id, onClick = null)
                Text(p.label, color = KColors.Text, modifier = Modifier.padding(start = 8.dp))
            }
        }
        Muted(current.note)
        Muted("Get a free key at ${current.signup} (sign-in required, no card). KRONOS ships without a key and stores yours only on this phone.")
        OutlinedTextField(
            value = key, onValueChange = { key = it; prefs.apiKey = it.trim(); engine.refreshAiStatus() },
            label = { Text("API key") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = model, onValueChange = { model = it; prefs.model = it.trim() },
            label = { Text("Model (blank = ${current.defaultModel})") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Muted("Providers rename and retire models. If the test fails with a model error, paste a current model name from the provider's website.")
        Button(onClick = { engine.testAi() }) { Text("Test AI connection") }
        Muted("Status: ${ui.ai}  ${ui.aiDetail}")

        Section("Voice and language")
        listOf("mixed" to "Hindi + English (Hinglish)", "hi" to "Hindi", "en" to "English").forEach { (id, label) ->
            Row(
                Modifier.fillMaxWidth().selectable(selected = language == id, role = Role.RadioButton) {
                    language = id; prefs.language = id
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = language == id, onClick = null)
                Text(label, color = KColors.Text, modifier = Modifier.padding(start = 8.dp))
            }
        }
        Text("Speaking speed: ${"%.1f".format(rate)}x", color = KColors.Text)
        Slider(
            value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.4f,
            onValueChangeFinished = { prefs.speechRate = rate }
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Prefer offline speech recognition", color = KColors.Text)
                Muted("Keeps your voice on the phone when an offline Hindi/English pack is installed. Otherwise Android's recognizer may send audio to Google.")
            }
            Switch(checked = offline, onCheckedChange = { offline = it; prefs.preferOffline = it })
        }
        OutlinedButton(onClick = {
            launchSafely(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
        }) { Text("Install / check voice data") }

        Section("Permissions (you stay in control)")
        Muted("Notification access lets KRONOS read the notifications on screen, only when you ask. Contents are not stored or uploaded. Verification-code messages are never read aloud.")
        OutlinedButton(onClick = { launchSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
            Text(if (KronosNotificationListener.isEnabled(ctx)) "Notification access: ON (manage)" else "Enable notification access")
        }
        Muted("All files access lets KRONOS list your Downloads folder to check for suspicious files and, only after you say yes, delete one.")
        OutlinedButton(onClick = {
            launchSafely(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        }) { Text(if (DownloadTools.hasAllFilesAccess()) "All files access: ON (manage)" else "Enable All files access") }

        Section("Honest limits")
        Muted(
            "- Download checks look at file names and types only. This is not an antivirus.\n" +
                "- Downloads are checked when you ask, not watched live.\n" +
                "- Apps can be opened directly only while KRONOS is on screen; otherwise you get a tap-to-open notification.\n" +
                "- Always-on \"Hello KRONOS\" is an emulation: Android reserves the real hotword for the system assistant.\n" +
                "- Free AI tiers have request limits and can change without notice.\n" +
                "- KRONOS never deletes, sends or pays for anything without your explicit yes."
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(8.dp))
    Text(title.uppercase(), color = KColors.Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun Muted(text: String) {
    Text(text, color = KColors.Muted, fontSize = 12.sp)
}
