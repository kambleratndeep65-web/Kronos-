package com.kronos.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class ChatMsg(val role: String, val content: String)

enum class ErrKind { NO_KEY, NO_INTERNET, AUTH, RATE_LIMIT, SERVER, PARSE }

sealed class AiResult {
    data class Ok(val text: String) : AiResult()
    data class Err(val kind: ErrKind, val message: String) : AiResult()
}

/** Request building and response parsing, separated from networking so it can be unit-tested. */
object AiParser {
    const val SYSTEM_PROMPT =
        "You are KRONOS, a voice assistant on the user's Android phone. Your replies are spoken aloud, " +
            "so keep them short (one to three sentences unless asked for more) in plain text: no markdown, " +
            "lists, emoji or URLs. Reply in the language the user used. If they speak English, reply in English. " +
            "If they speak Hindi or Hinglish, reply in Hindi written in Devanagari script (common English " +
            "technical words may stay in English). You cannot control the phone yourself: the app handles " +
            "opening apps, time, date, notifications and downloads locally. Never claim to have performed an " +
            "action. If you are unsure, say so instead of inventing facts."

    fun buildRequest(model: String, system: String, history: List<ChatMsg>, maxTokens: Int = 400): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        return JSONObject()
            .put("model", model)
            .put("messages", msgs)
            .put("temperature", 0.6)
            .put("max_tokens", maxTokens)
            .toString()
    }

    fun parseReply(body: String): String? = try {
        JSONObject(body).optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content", "")?.trim()
            ?.takeIf { it.isNotEmpty() }
    } catch (e: JSONException) {
        null
    }

    fun classify(httpCode: Int): ErrKind = when (httpCode) {
        401, 403 -> ErrKind.AUTH
        429 -> ErrKind.RATE_LIMIT
        else -> ErrKind.SERVER
    }
}

class AiClient(private val prefs: Prefs) {

    suspend fun chat(history: List<ChatMsg>): AiResult = withContext(Dispatchers.IO) {
        val key = prefs.apiKey.trim()
        if (key.isEmpty()) return@withContext AiResult.Err(ErrKind.NO_KEY, "No API key set")
        val provider = Provider.fromId(prefs.provider)
        val model = prefs.model.ifBlank { provider.defaultModel }
        val body = AiParser.buildRequest(model, AiParser.SYSTEM_PROMPT, history)

        var conn: HttpURLConnection? = null
        try {
            conn = (URL(provider.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 30_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $key")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                return@withContext AiResult.Err(AiParser.classify(code), "HTTP $code: ${text.take(200)}")
            }
            val reply = AiParser.parseReply(text)
                ?: return@withContext AiResult.Err(ErrKind.PARSE, "Unexpected response from AI service")
            AiResult.Ok(reply)
        } catch (e: UnknownHostException) {
            AiResult.Err(ErrKind.NO_INTERNET, "Cannot reach ${provider.label}")
        } catch (e: SocketTimeoutException) {
            AiResult.Err(ErrKind.NO_INTERNET, "Request timed out")
        } catch (e: IOException) {
            AiResult.Err(ErrKind.NO_INTERNET, e.message ?: "Network error")
        } finally {
            conn?.disconnect()
        }
    }

    /** Smallest possible real request, used by the "Test AI connection" button. */
    suspend fun ping(): AiResult = chat(listOf(ChatMsg("user", "Reply with the single word: OK")))
}
