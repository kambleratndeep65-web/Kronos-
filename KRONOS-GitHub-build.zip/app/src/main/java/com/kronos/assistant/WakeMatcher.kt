package com.kronos.assistant

data class WakeResult(val matched: Boolean, val remainder: String = "")

/**
 * Text-level matcher for the wake phrase "Hello KRONOS". Speech recognizers spell the name many ways
 * (Cronos, Chronos, क्रोनोस ...), so this accepts common variants in English and Devanagari.
 * Anything said after the phrase is returned as [WakeResult.remainder] so "Hello KRONOS what time is it" works.
 */
object WakeMatcher {
    private val pattern = Regex(
        "(?<!\\p{L})(?:hello|hallo|hullo|helo|hi|hey|हेलो|हैलो|हेल्लो|हलो|हैल्लो)[\\s,.!-]*" +
            "(?:kronos|cronos|chronos|kronus|cronus|kranos|krono|क्रोनोस|क्रोनस|क्रोनॉस|क्रोनोज़|क्रोनोज|क्रॉनोस)",
        RegexOption.IGNORE_CASE
    )

    fun match(text: String): WakeResult {
        val m = pattern.find(text) ?: return WakeResult(false)
        val rest = text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '-')
        return WakeResult(true, rest)
    }
}
